package com.lumafloat

import android.content.Context
import android.content.SharedPreferences

/** Semua preferensi disimpan lokal (SharedPreferences). Tidak ada data keluar perangkat. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("luma_prefs", Context.MODE_PRIVATE)

    val raw: SharedPreferences get() = sp

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }
    var bubbleSize: Int
        get() = sp.getInt("bubbleSize", 56)
        set(v) { sp.edit().putInt("bubbleSize", v).apply() }
    var panelAlpha: Int
        get() = sp.getInt("panelAlpha", 94)
        set(v) { sp.edit().putInt("panelAlpha", v).apply() }
    var panelScale: Int
        get() = sp.getInt("panelScale", 1)
        set(v) { sp.edit().putInt("panelScale", v).apply() }
    var panelW: Int
        get() = sp.getInt("panelW", 0)
        set(v) { sp.edit().putInt("panelW", v).apply() }
    var panelH: Int
        get() = sp.getInt("panelH", 0)
        set(v) { sp.edit().putInt("panelH", v).apply() }
    var anim: Int
        get() = sp.getInt("anim", 2)
        set(v) { sp.edit().putInt("anim", v).apply() }
    var bubbleX: Int
        get() = sp.getInt("bubbleX", -1)
        set(v) { sp.edit().putInt("bubbleX", v).apply() }
    var bubbleY: Int
        get() = sp.getInt("bubbleY", -1)
        set(v) { sp.edit().putInt("bubbleY", v).apply() }
    var launchMode: Int
        get() = sp.getInt("launchMode", 0)
        set(v) { sp.edit().putInt("launchMode", v).apply() }
    var autostart: Boolean
        get() = sp.getBoolean("autostart", false)
        set(v) { sp.edit().putBoolean("autostart", v).apply() }
    var serviceWanted: Boolean
        get() = sp.getBoolean("serviceWanted", false)
        set(v) { sp.edit().putBoolean("serviceWanted", v).apply() }
    var notes: String
        get() = sp.getString("notes", "") ?: ""
        set(v) { sp.edit().putString("notes", v).apply() }

    /** 0 = mati, 0.6 = ringan, 1 = normal */
    val animFactor: Float
        get() = when (anim) {
            0 -> 0f
            1 -> 0.6f
            else -> 1f
        }

    private fun list(key: String): MutableList<String> =
        (sp.getString(key, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun save(key: String, l: List<String>) {
        sp.edit().putString(key, l.joinToString(",")).apply()
    }

    fun favorites(): List<String> = list("favs")
    fun isFavorite(pkg: String): Boolean = list("favs").contains(pkg)

    fun toggleFavorite(pkg: String): Boolean {
        val l = list("favs")
        val added = if (l.contains(pkg)) {
            l.remove(pkg); false
        } else {
            l.add(0, pkg); true
        }
        save("favs", l)
        return added
    }

    fun recents(): List<String> = list("recents")

    fun addRecent(pkg: String) {
        val l = list("recents")
        l.remove(pkg)
        l.add(0, pkg)
        while (l.size > 8) l.removeAt(l.size - 1)
        save("recents", l)
    }

    fun resetBubblePosition() {
        sp.edit().putInt("bubbleX", -1).putInt("bubbleY", -1)
            .putInt("resetTick", sp.getInt("resetTick", 0) + 1).apply()
    }
}
