package com.lumafloat

import java.math.BigDecimal
import java.math.MathContext

/** Evaluator ekspresi sederhana: + - × ÷ %, desimal, minus unary. */
object Calc {
    private class P(val s: String) { var i = 0 }

    fun eval(src: String): Double? {
        val s = src.replace("\u00D7", "*").replace("\u00F7", "/").replace("\u2212", "-").replace(" ", "")
        if (s.isEmpty()) return null
        return try {
            val p = P(s)
            val v = expr(p)
            if (p.i != s.length || v.isNaN() || v.isInfinite()) null else v
        } catch (e: Exception) {
            null
        }
    }

    private fun expr(p: P): Double {
        var v = term(p)
        while (p.i < p.s.length) {
            val c = p.s[p.i]
            if (c == '+') { p.i++; v += term(p) }
            else if (c == '-') { p.i++; v -= term(p) }
            else break
        }
        return v
    }

    private fun term(p: P): Double {
        var v = factor(p)
        while (p.i < p.s.length) {
            val c = p.s[p.i]
            if (c == '*') { p.i++; v *= factor(p) }
            else if (c == '/') {
                p.i++
                val d = factor(p)
                if (d == 0.0) throw ArithmeticException("div0")
                v /= d
            } else break
        }
        return v
    }

    private fun factor(p: P): Double {
        if (p.i >= p.s.length) throw IllegalArgumentException("end")
        var neg = false
        while (p.i < p.s.length && (p.s[p.i] == '-' || p.s[p.i] == '+')) {
            if (p.s[p.i] == '-') neg = !neg
            p.i++
        }
        val st = p.i
        while (p.i < p.s.length && (p.s[p.i].isDigit() || p.s[p.i] == '.')) p.i++
        if (st == p.i) throw IllegalArgumentException("num")
        var v = p.s.substring(st, p.i).toDouble()
        while (p.i < p.s.length && p.s[p.i] == '%') { v /= 100.0; p.i++ }
        return if (neg) -v else v
    }

    fun format(v: Double): String {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }
}
