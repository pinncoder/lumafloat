package com.lumafloat

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build

data class AppInfo(val pkg: String, val label: String, val icon: Drawable?, val launchable: Boolean)

object AppRepo {
    const val CHROME = "com.android.chrome"
    const val WA = "com.whatsapp"
    const val WA_BIZ = "com.whatsapp.w4b"

    private var cache: List<AppInfo>? = null

    fun invalidate() { cache = null }

    fun isInstalled(c: Context, pkg: String): Boolean =
        c.packageManager.getLaunchIntentForPackage(pkg) != null

    /** WhatsApp biasa; jika tidak ada tapi WhatsApp Business terpasang, pakai itu. */
    fun whatsapp(c: Context): String =
        if (!isInstalled(c, WA) && isInstalled(c, WA_BIZ)) WA_BIZ else WA

    fun label(c: Context, pkg: String): String = when {
        pkg == CHROME && !isInstalled(c, pkg) -> "Google Chrome"
        pkg == WA && !isInstalled(c, pkg) -> "WhatsApp"
        else -> try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun icon(c: Context, pkg: String): Drawable? = try {
        c.packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }

    /** Aplikasi yang punya launcher activity. WhatsApp & Chrome selalu di urutan teratas. */
    @Synchronized
    fun load(c: Context): List<AppInfo> {
        cache?.let { return it }
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val res = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            pm.queryIntentActivities(intent, 0)
        }
        val seen = HashSet<String>()
        val out = ArrayList<AppInfo>()
        for (r in res) {
            val pkg = r.activityInfo.packageName
            if (pkg == c.packageName || !seen.add(pkg)) continue
            out.add(AppInfo(pkg, r.loadLabel(pm).toString(), r.loadIcon(pm), true))
        }
        val pinned = listOf(whatsapp(c), CHROME).map { p ->
            out.firstOrNull { it.pkg == p }
                ?: AppInfo(p, if (p == CHROME) "Google Chrome" else "WhatsApp", null, false)
        }
        val rest = out.filter { a -> pinned.none { it.pkg == a.pkg } }.sortedBy { it.label.lowercase() }
        val all = pinned + rest
        cache = all
        return all
    }
}
