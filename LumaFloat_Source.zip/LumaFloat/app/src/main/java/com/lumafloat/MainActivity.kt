package com.lumafloat

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        var tab = 0
    }

    private lateinit var prefs: Prefs
    private lateinit var pal: Palette
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) {
            AppRepo.invalidate()
            showTab(tab)
        }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------ kerangka

    private fun buildUi() {
        pal = Pal.of(prefs)
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.surface
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.bg)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(pal.surface)
        nav.setPadding(dp(8), dp(6), dp(8), dp(6))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        showTab(tab)
    }

    private fun rebuildNav() {
        nav.removeAllViews()
        val items = listOf(
            Triple("Home", R.drawable.ic_home, 0),
            Triple("Apps", R.drawable.ic_apps, 1),
            Triple("Tampilan", R.drawable.ic_tune, 2),
            Triple("Setelan", R.drawable.ic_settings, 3)
        )
        for ((label, res, idx) in items) {
            val sel = idx == tab
            val r = dpf(16f)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(dp(4), dp(8), dp(4), dp(8))
            col.background = Ui.ripple(Ui.round(if (sel) pal.surface2 else Color.TRANSPARENT, r), r)
            col.addView(Ui.icon(this, res, if (sel) pal.accent2 else pal.dim, 22))
            col.addView(Ui.text(this, label, 11f, if (sel) pal.text else pal.dim, sel))
            col.setOnClickListener { showTab(idx) }
            nav.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun showTab(i: Int) {
        tab = i
        rebuildNav()
        content.removeAllViews()
        val v = when (i) {
            0 -> homePage()
            1 -> appsPage()
            2 -> appearancePage()
            else -> settingsPage()
        }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
        val f = prefs.animFactor
        if (f > 0f) {
            v.alpha = 0f
            v.animate().alpha(1f).setDuration((180 * f).toLong()).start()
        }
    }

    private fun page(build: (LinearLayout) -> Unit): View {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(24))
        build(col)
        sv.addView(col, FrameLayout.LayoutParams(-1, -2))
        return sv
    }

    private fun pageTitle(col: LinearLayout, t: String, sub: String) {
        col.add(Ui.text(this, t, 24f, pal.text, true))
        col.add(Ui.text(this, sub, 13f, pal.dim), t = 2, b = 14)
    }

    private fun section(col: LinearLayout, t: String) {
        col.add(Ui.text(this, t.uppercase(), 11f, pal.dim, true), t = 14, b = 6, l = 4)
    }

    // ------------------------------------------------------------ aksi umum

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e2: Exception) {
                Toast.makeText(this, "Buka manual: Setelan > Aplikasi > LUMA FLOAT > Tampil di atas aplikasi lain", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshSoon() {
        main.postDelayed({ if (!isDestroyed && !isFinishing) showTab(tab) }, 350)
    }

    private fun toggleService() {
        if (FloatingService.running) {
            FloatingService.stop(this)
            refreshSoon()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan dulu izin 'Tampilkan di atas aplikasi lain'", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        try {
            FloatingService.start(this)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memulai layanan: ${e.message}", Toast.LENGTH_LONG).show()
        }
        refreshSoon()
    }

    private fun openUrlSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            Toast.makeText(this, "Halaman pengaturan ini tidak tersedia di perangkat", Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------ HOME

    private fun quickTile(pkg: String, name: String): View {
        val inst = AppRepo.isInstalled(this, pkg)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(12), dp(16), dp(12), dp(14))
        box.background = Ui.ripple(Ui.round(pal.surface, dpf(20f), pal.stroke, dp(1)), dpf(20f))
        val iv = ImageView(this)
        val d = AppRepo.icon(this, pkg)
        if (d != null) iv.setImageDrawable(d)
        else iv.setImageDrawable(getDrawable(R.drawable.ic_apps)?.mutate()?.also { it.setTint(pal.dim) })
        iv.alpha = if (inst) 1f else 0.5f
        box.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
        val t = Ui.text(this, name, 14f, pal.text, true)
        t.gravity = Gravity.CENTER
        box.add(t, t = 8)
        val s = Ui.text(this, if (inst) "Terpasang \u2022 ketuk untuk buka" else "Belum terpasang", 11f, pal.dim)
        s.gravity = Gravity.CENTER
        box.add(s, t = 2)
        box.setOnClickListener {
            if (inst) Launcher.launch(this, pkg, prefs) else Launcher.notInstalled(this, pkg)
        }
        return box
    }

    private fun infoTile(label: String, value: String, ok: Boolean, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(14), dp(14), dp(14))
        box.background = Ui.ripple(Ui.round(pal.surface, dpf(18f), pal.stroke, dp(1)), dpf(18f))
        box.add(Ui.text(this, label, 11f, pal.dim, true))
        box.add(Ui.text(this, value, 13f, if (ok) pal.accent2 else pal.text, true), t = 4)
        box.setOnClickListener { onClick() }
        return box
    }

    private fun dot(color: Int): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        v.background = g
        v.layoutParams = LinearLayout.LayoutParams(dp(10), dp(10))
        return v
    }

    private fun homePage(): View = page { col ->
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = FrameLayout(this)
        logo.background = Ui.grad(pal.accent, pal.accent2, dpf(14f))
        logo.addView(Ui.icon(this, R.drawable.ic_bolt, pal.onAccent, 24), FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        head.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.add(Ui.text(this, "LUMA FLOAT", 21f, pal.text, true))
        names.add(Ui.text(this, "Floating launcher premium", 12f, pal.dim))
        head.add(names, w = 0, wt = 1f, l = 12)
        col.add(head, b = 16)

        val running = FloatingService.running
        val wanted = prefs.serviceWanted
        val card = Ui.card(this, pal, 18)
        val st = LinearLayout(this)
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        st.addView(dot(if (running) 0xFF34D399.toInt() else if (wanted) 0xFFF59E0B.toInt() else pal.dim))
        val stText = when {
            running -> "Layanan floating aktif"
            wanted -> "Layanan dihentikan sistem"
            else -> "Layanan floating mati"
        }
        st.add(Ui.text(this, stText, 16f, pal.text, true), l = 10)
        card.add(st)
        val desc = when {
            running -> "Bubble tampil di layar. Ketuk bubble untuk membuka panel."
            wanted -> "Android/XOS menghentikan layanan di latar belakang. Ketuk Mulai untuk mengaktifkan lagi, lalu lihat panduan di Setelan."
            else -> "Mulai layanan untuk menampilkan bubble pengambang."
        }
        card.add(Ui.text(this, desc, 12f, pal.dim), t = 6, b = 14)
        card.add(
            if (running) Ui.button(this, "Hentikan Floating", pal.surface2, pal.text) { toggleService() }
            else Ui.gradButton(this, pal, "Mulai Floating") { toggleService() }
        )
        col.add(card)

        section(col, "Peluncuran cepat")
        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        tiles.add(quickTile(AppRepo.whatsapp(this), "WhatsApp"), w = 0, wt = 1f)
        tiles.add(quickTile(AppRepo.CHROME, "Chrome"), w = 0, wt = 1f, l = 10)
        col.add(tiles)

        section(col, "Status")
        val granted = Settings.canDrawOverlays(this)
        val stat = LinearLayout(this)
        stat.orientation = LinearLayout.HORIZONTAL
        stat.add(
            infoTile("Izin overlay", if (granted) "Aktif" else "Belum diberikan \u2022 ketuk", granted) {
                if (!granted) openOverlaySettings()
            }, w = 0, wt = 1f
        )
        stat.add(
            infoTile("Multi-window", Compat.summary(this), false) { showTab(3) },
            w = 0, wt = 1f, l = 10
        )
        col.add(stat)

        section(col, "Fitur")
        val feats = listOf(
            "Bubble yang bisa digeser" to "Ketuk untuk membuka panel. Bubble menempel ke tepi layar dan memudar saat tidak dipakai.",
            "Panel aplikasi mengambang" to "Favorit, WhatsApp, Chrome, dan riwayat. Ukuran panel dapat digeser dan diubah.",
            "Alat mini" to "Kalkulator, timer, dan catatan cepat langsung di dalam panel."
        )
        for ((t, d) in feats) {
            val c = Ui.card(this, pal, 14)
            c.add(Ui.text(this, t, 14f, pal.text, true))
            c.add(Ui.text(this, d, 12f, pal.dim), t = 3)
            col.add(c, b = 8)
        }
    }

    // ------------------------------------------------------------ APPS

    private class Holder {
        lateinit var icon: ImageView
        lateinit var label: TextView
        lateinit var sub: TextView
        lateinit var star: TextView
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppInfo> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        private fun newRow(h: Holder): View {
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(4), dp(10))
            row.background = Ui.ripple(Ui.round(pal.surface, dpf(16f), pal.stroke, dp(1)), dpf(16f))
            h.icon = ImageView(this@MainActivity)
            row.addView(h.icon, LinearLayout.LayoutParams(dp(40), dp(40)))
            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            h.label = Ui.text(this@MainActivity, "", 15f, pal.text, true)
            h.label.maxLines = 1
            h.label.ellipsize = TextUtils.TruncateAt.END
            h.sub = Ui.text(this@MainActivity, "", 11f, pal.dim)
            h.sub.maxLines = 1
            h.sub.ellipsize = TextUtils.TruncateAt.END
            col.addView(h.label)
            col.addView(h.sub)
            row.add(col, w = 0, wt = 1f, l = 12)
            h.star = Ui.text(this@MainActivity, "", 22f, pal.dim)
            h.star.setPadding(dp(12), dp(6), dp(12), dp(6))
            row.addView(h.star)
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val h: Holder
            val row: View
            if (convertView == null) {
                h = Holder()
                row = newRow(h)
                row.tag = h
            } else {
                row = convertView
                h = convertView.tag as Holder
            }
            val a = items[position]
            if (a.icon != null) {
                h.icon.setImageDrawable(a.icon)
                h.icon.alpha = 1f
            } else {
                h.icon.setImageDrawable(getDrawable(R.drawable.ic_apps)?.mutate()?.also { it.setTint(pal.dim) })
                h.icon.alpha = 0.6f
            }
            h.label.text = a.label
            val priority = a.pkg == AppRepo.CHROME || a.pkg == AppRepo.WA || a.pkg == AppRepo.WA_BIZ
            h.sub.text = when {
                !a.launchable -> "Belum terpasang \u2022 ketuk untuk Play Store"
                priority -> "Prioritas \u2022 siap diluncurkan"
                else -> "Siap diluncurkan"
            }
            val fav = prefs.isFavorite(a.pkg)
            h.star.text = if (fav) "\u2605" else "\u2606"
            h.star.setTextColor(if (fav) pal.accent2 else pal.dim)
            h.star.visibility = if (a.launchable) View.VISIBLE else View.GONE
            h.star.setOnClickListener {
                prefs.toggleFavorite(a.pkg)
                notifyDataSetChanged()
            }
            return row
        }
    }

    private fun appsPage(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), 0)
        pageTitle(root, "Aplikasi", "Ketuk untuk membuka \u2022 \u2606 untuk favorit panel")

        val search = EditText(this)
        search.hint = "Cari aplikasi\u2026"
        search.setHintTextColor(pal.dim)
        search.setTextColor(pal.text)
        search.textSize = 15f
        search.maxLines = 1
        search.setSingleLine(true)
        search.background = Ui.round(pal.surface, dpf(16f), pal.stroke, dp(1))
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.add(search, b = 10)

        val adapter = AppAdapter()
        val lv = ListView(this)
        lv.divider = ColorDrawable(Color.TRANSPARENT)
        lv.dividerHeight = dp(8)
        lv.setSelector(ColorDrawable(Color.TRANSPARENT))
        lv.cacheColorHint = Color.TRANSPARENT
        lv.isVerticalScrollBarEnabled = false
        lv.setPadding(0, 0, 0, dp(12))
        lv.clipToPadding = false
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            val a = adapter.items[pos]
            if (a.launchable) Launcher.launch(this, a.pkg, prefs) else Launcher.notInstalled(this, a.pkg)
        }
        root.add(lv, h = 0, wt = 1f)

        var all: List<AppInfo> = emptyList()
        fun applyFilter() {
            val q = search.text.toString().trim()
            adapter.items = if (q.isEmpty()) all else all.filter {
                it.label.contains(q, ignoreCase = true) || it.pkg.contains(q, ignoreCase = true)
            }
            adapter.notifyDataSetChanged()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        Thread {
            val list = AppRepo.load(applicationContext)
            runOnUiThread {
                if (!isDestroyed) {
                    all = list
                    applyFilter()
                }
            }
        }.start()
        return root
    }

    // ------------------------------------------------------------ TAMPILAN

    private fun seekRow(title: String, lo: Int, hi: Int, value: Int, unit: String, onDone: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val label = Ui.text(this, "$title: $value$unit", 14f, pal.text)
        box.addView(label)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.progressTintList = ColorStateList.valueOf(pal.accent)
        sb.thumbTintList = ColorStateList.valueOf(pal.accent2)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                label.text = "$title: ${p + lo}$unit"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { onDone(s.progress + lo) }
        })
        box.add(sb, t = 6)
        return box
    }

    private fun appearancePage(): View = page { col ->
        pageTitle(col, "Tampilan", "Disimpan lokal \u2022 langsung diterapkan ke bubble yang aktif")

        var c = Ui.card(this, pal)
        c.add(Ui.text(this, "Tema", 14f, pal.text, true), b = 8)
        c.add(Ui.chips(this, pal, Pal.themeNames, prefs.theme) { prefs.theme = it; buildUi() })
        c.add(Ui.text(this, "Warna aksen", 14f, pal.text, true), t = 14, b = 8)
        c.add(Ui.chips(this, pal, Pal.accentNames, prefs.accent) { prefs.accent = it; buildUi() })
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(seekRow("Ukuran bubble", 44, 80, prefs.bubbleSize, " dp") { prefs.bubbleSize = it })
        c.add(seekRow("Transparansi panel (opasitas)", 55, 100, prefs.panelAlpha, "%") { prefs.panelAlpha = it }, t = 16)
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(Ui.text(this, "Ukuran panel", 14f, pal.text, true), b = 8)
        val sizeSel = if (prefs.panelW > 0 || prefs.panelH > 0) -1 else prefs.panelScale
        c.add(Ui.chips(this, pal, listOf("Kecil", "Sedang", "Besar"), sizeSel) {
            prefs.panelW = 0
            prefs.panelH = 0
            prefs.panelScale = it
            showTab(2)
        })
        c.add(
            Ui.text(this, "Anda juga bisa menarik pojok kanan-bawah panel untuk mengubah ukuran, dan menggeser header untuk memindahkannya.", 12f, pal.dim),
            t = 8
        )
        c.add(Ui.text(this, "Intensitas animasi", 14f, pal.text, true), t = 14, b = 8)
        c.add(Ui.chips(this, pal, listOf("Mati", "Ringan", "Normal"), prefs.anim) { prefs.anim = it; showTab(2) })
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(Ui.button(this, "Reset posisi bubble", pal.surface2, pal.text) {
            prefs.resetBubblePosition()
            Toast.makeText(this, "Posisi bubble direset", Toast.LENGTH_SHORT).show()
        })
        col.add(c)
    }

    // ------------------------------------------------------------ SETELAN

    private fun kv(col: LinearLayout, k: String, v: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.add(Ui.text(this, k, 12f, pal.dim), w = 0, wt = 1f)
        val vt = Ui.text(this, v, 12f, pal.text, true)
        vt.gravity = Gravity.END
        row.add(vt, w = 0, wt = 1f, l = 8)
        col.add(row, t = 6)
    }

    private fun settingsPage(): View = page { col ->
        pageTitle(col, "Setelan", "Izin, layanan, dan kompatibilitas")

        val granted = Settings.canDrawOverlays(this)
        var c = Ui.card(this, pal)
        c.add(Ui.text(this, "Izin 'Tampilkan di atas aplikasi lain'", 14f, pal.text, true))
        c.add(Ui.text(this, if (granted) "Status: aktif" else "Status: belum diberikan atau dicabut", 13f,
            if (granted) pal.accent2 else 0xFFF59E0B.toInt()), t = 4, b = 10)
        c.add(Ui.button(this, "Buka pengaturan izin overlay", pal.surface2, pal.text) { openOverlaySettings() })
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        val running = FloatingService.running
        c.add(Ui.text(this, "Layanan floating", 14f, pal.text, true))
        c.add(Ui.text(this, if (running) "Status: aktif" else if (prefs.serviceWanted) "Status: dihentikan sistem" else "Status: mati", 13f, pal.dim), t = 4, b = 10)
        c.add(
            if (running) Ui.button(this, "Hentikan layanan", pal.surface2, pal.text) { toggleService() }
            else Ui.gradButton(this, pal, "Mulai layanan") { toggleService() }
        )
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(Ui.text(this, "Mode peluncuran aplikasi", 14f, pal.text, true), b = 8)
        c.add(Ui.chips(this, pal, listOf("Normal", "Berdampingan", "Jendela bebas"), prefs.launchMode) {
            prefs.launchMode = it
            showTab(3)
        })
        val modeDesc = when (prefs.launchMode) {
            1 -> "Meminta Android membuka aplikasi di sisi layar split-screen (FLAG_ACTIVITY_LAUNCH_ADJACENT). Hanya efektif jika layar sudah dalam split-screen; jika tidak, aplikasi dibuka normal."
            2 -> "Mengirim ukuran jendela yang diminta (launch bounds). Hanya dihormati jika freeform diaktifkan perangkat; jika tidak, sistem mengabaikannya dan membuka normal."
            else -> "Membuka aplikasi layar penuh. Selalu berfungsi."
        }
        c.add(Ui.text(this, modeDesc, 12f, pal.dim), t = 8)
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        txt.add(Ui.text(this, "Mulai otomatis saat boot", 14f, pal.text, true))
        txt.add(Ui.text(this, "Beberapa HP (termasuk XOS) memblokir autostart; lihat panduan di bawah.", 12f, pal.dim), t = 2)
        row.add(txt, w = 0, wt = 1f)
        val sw = Switch(this)
        sw.isChecked = prefs.autostart
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(pal.accent2, pal.dim))
        sw.trackTintList = ColorStateList(states, intArrayOf(Ui.alpha(pal.accent, 0x88), pal.surface2))
        sw.setOnCheckedChangeListener { _, on -> prefs.autostart = on }
        row.addView(sw)
        c.add(row)
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(Ui.text(this, "Kompatibilitas Android / XOS", 14f, pal.text, true), b = 4)
        for ((k, v) in Compat.lines(this)) kv(c, k, v)
        c.add(
            Ui.text(this, "Ini hanya indikasi dari sistem, bukan hasil uji pada perangkat Anda. Overlay saja tidak mengubah WhatsApp/Chrome menjadi jendela kecil.", 12f, pal.dim),
            t = 10
        )
        c.add(Ui.button(this, "Buka Opsi Pengembang", pal.surface2, pal.text) {
            openUrlSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        }, t = 10)
        c.add(Ui.button(this, "Info aplikasi / baterai", pal.surface2, pal.text) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak dapat membuka info aplikasi", Toast.LENGTH_SHORT).show()
            }
        }, t = 8)
        col.add(c, b = 10)

        c = Ui.card(this, pal)
        c.add(Ui.text(this, "Pemecahan masalah", 14f, pal.text, true), b = 6)
        val tips = listOf(
            "Bubble tidak muncul: pastikan izin overlay aktif, lalu Hentikan dan Mulai lagi layanan.",
            "Bubble hilang sendiri: buka Info aplikasi > Baterai, pilih Tanpa batasan; di XOS cek juga Phone Master / Autostart / kunci aplikasi di recent apps.",
            "Notifikasi tidak terlihat: izinkan notifikasi untuk LUMA FLOAT; layanan tetap berjalan tanpanya.",
            "Aplikasi tidak jadi jendela kecil: itu keterbatasan sistem. Gunakan mode Normal atau split-screen bawaan XOS.",
            "Setelah izin dicabut Android dapat menutup aplikasi; buka lagi dan berikan izin."
        )
        for (t in tips) c.add(Ui.text(this, "\u2022 $t", 12f, pal.dim), t = 6)
        col.add(c, b = 10)

        col.add(Ui.text(this, "LUMA FLOAT 1.0.0 \u2022 tanpa iklan, tanpa analytics, tanpa akses internet", 11f, pal.dim).also {
            (it as TextView).gravity = Gravity.CENTER
        }, t = 6)
    }
}
