package com.lumafloat

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Tambah child ke LinearLayout; ukuran/margin dalam dp. */
fun LinearLayout.add(
    v: View,
    w: Int = ViewGroup.LayoutParams.MATCH_PARENT,
    h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0,
    wt: Float = 0f
): View {
    val lp = LinearLayout.LayoutParams(w, h, wt)
    lp.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    addView(v, lp)
    return v
}

class Palette(
    val bg: Int, val surface: Int, val surface2: Int, val stroke: Int,
    val text: Int, val dim: Int, val accent: Int, val accent2: Int
) {
    val onAccent: Int = 0xFF05070F.toInt()
}

object Pal {
    val themeNames = listOf("AMOLED", "Midnight", "Graphite")
    val accentNames = listOf("Violet", "Cyan", "Rose")
    private val accents = arrayOf(
        intArrayOf(0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt()),
        intArrayOf(0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt()),
        intArrayOf(0xFFFF4D8D.toInt(), 0xFF7C4DFF.toInt())
    )

    fun of(p: Prefs): Palette {
        val t = p.theme.coerceIn(0, 2)
        val a = p.accent.coerceIn(0, 2)
        val bg: Int
        val s1: Int
        val s2: Int
        when (t) {
            0 -> { bg = 0xFF04060D.toInt(); s1 = 0xFF0C1122.toInt(); s2 = 0xFF151D36.toInt() }
            1 -> { bg = 0xFF0A1024.toInt(); s1 = 0xFF121B38.toInt(); s2 = 0xFF1B2750.toInt() }
            else -> { bg = 0xFF08090B.toInt(); s1 = 0xFF131418.toInt(); s2 = 0xFF1D1F25.toInt() }
        }
        return Palette(
            bg, s1, s2, 0x1FFFFFFF, 0xFFF2F4FA.toInt(), 0xFF9AA3BC.toInt(),
            accents[a][0], accents[a][1]
        )
    }
}

object Ui {
    fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or ((a and 0xFF) shl 24)

    fun round(color: Int, r: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = r
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun grad(c1: Int, c2: Int, r: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = r }

    fun ripple(content: Drawable, r: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), content, round(Color.WHITE, r))

    fun text(c: Context, s: CharSequence, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(c)
        tv.text = s
        tv.textSize = sp
        tv.setTextColor(color)
        tv.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        return tv
    }

    fun icon(c: Context, res: Int, tint: Int, sizeDp: Int): ImageView {
        val iv = ImageView(c)
        val d = c.getDrawable(res)?.mutate()
        d?.setTint(tint)
        iv.setImageDrawable(d)
        iv.layoutParams = ViewGroup.LayoutParams(c.dp(sizeDp), c.dp(sizeDp))
        return iv
    }

    fun button(c: Context, label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        val r = c.dpf(14f)
        val tv = text(c, label, 14f, fg, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(c.dp(14), c.dp(12), c.dp(14), c.dp(12))
        tv.background = ripple(round(bg, r), r)
        tv.setOnClickListener { onClick() }
        return tv
    }

    fun gradButton(c: Context, p: Palette, label: String, onClick: () -> Unit): TextView {
        val r = c.dpf(16f)
        val tv = text(c, label, 15f, p.onAccent, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(c.dp(16), c.dp(14), c.dp(16), c.dp(14))
        tv.background = ripple(grad(p.accent, p.accent2, r), r)
        tv.setOnClickListener { onClick() }
        return tv
    }

    fun card(c: Context, p: Palette, pad: Int = 16): LinearLayout {
        val ll = LinearLayout(c)
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(c.dp(pad), c.dp(pad), c.dp(pad), c.dp(pad))
        ll.background = round(p.surface, c.dpf(20f), p.stroke, c.dp(1))
        return ll
    }

    fun chips(c: Context, p: Palette, options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        options.forEachIndexed { i, name ->
            val on = i == selected
            val r = c.dpf(12f)
            val t = text(c, name, 13f, if (on) p.onAccent else p.dim, on)
            t.gravity = Gravity.CENTER
            t.setPadding(c.dp(6), c.dp(10), c.dp(6), c.dp(10))
            t.background = if (on) ripple(grad(p.accent, p.accent2, r), r) else ripple(round(p.surface2, r), r)
            t.setOnClickListener { onSelect(i) }
            row.add(t, w = 0, wt = 1f, l = if (i == 0) 0 else 6)
        }
        return row
    }
}
