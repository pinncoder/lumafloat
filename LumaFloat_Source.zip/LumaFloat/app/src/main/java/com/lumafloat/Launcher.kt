package com.lumafloat

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/**
 * Peluncuran aplikasi lewat API publik. Mode:
 *  0 = normal (layar penuh, selalu bekerja)
 *  1 = berdampingan: FLAG_ACTIVITY_LAUNCH_ADJACENT (hanya efektif bila sistem sedang split-screen)
 *  2 = jendela bebas: setLaunchBounds (hanya dihormati bila freeform diaktifkan oleh sistem/XOS)
 * Aplikasi TIDAK mengetahui apakah mode 1/2 dihormati sistem; bila tidak, aplikasi dibuka normal.
 */
object Launcher {
    fun launch(c: Context, pkg: String, prefs: Prefs): Boolean {
        val intent = c.packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            notInstalled(c, pkg)
            return false
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        var opts: Bundle? = null
        when (prefs.launchMode) {
            1 -> intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            2 -> {
                val m = c.resources.displayMetrics
                val w = (m.widthPixels * 0.8f).toInt()
                val h = (m.heightPixels * 0.55f).toInt()
                val l = (m.widthPixels - w) / 2
                val t = (m.heightPixels * 0.12f).toInt()
                opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h)).toBundle()
            }
        }
        return try {
            c.startActivity(intent, opts)
            prefs.addRecent(pkg)
            true
        } catch (e: Exception) {
            Toast.makeText(c, "Gagal membuka aplikasi", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun notInstalled(c: Context, pkg: String) {
        Toast.makeText(c, "${AppRepo.label(c, pkg)} belum terpasang", Toast.LENGTH_SHORT).show()
        val targets = listOf(
            "market://details?id=$pkg",
            "https://play.google.com/store/apps/details?id=$pkg"
        )
        for (u in targets) {
            try {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {
                // coba target berikutnya
            }
        }
    }
}
