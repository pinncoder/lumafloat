package com.lumafloat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Memulai layanan setelah boot, hanya jika pengguna mengaktifkannya dan izin overlay masih ada. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = Prefs(context)
        if (p.autostart && Settings.canDrawOverlays(context)) {
            try {
                FloatingService.start(context)
            } catch (e: Exception) {
                // sistem/OEM dapat memblokir autostart; abaikan
            }
        }
    }
}
