package com.lumafloat

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/** Informasi kompatibilitas yang dapat dibaca aplikasi. Ini INDIKASI, bukan jaminan. */
object Compat {
    fun overlayGranted(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun freeformFeature(c: Context): Boolean =
        c.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)

    /** 1 = aktif, 0 = nonaktif, -1 = tidak terbaca */
    fun freeformSetting(c: Context): Int = try {
        Settings.Global.getInt(c.contentResolver, "enable_freeform_support")
    } catch (e: Exception) {
        -1
    }

    fun summary(c: Context): String {
        val f = freeformFeature(c)
        val s = freeformSetting(c)
        return when {
            f && s == 1 -> "Freeform mungkin tersedia"
            f -> "Freeform: aktifkan di Opsi Pengembang"
            s == 1 -> "Opsi freeform aktif, belum terverifikasi"
            else -> "Freeform tidak terdeteksi (pakai fallback)"
        }
    }

    fun lines(c: Context): List<Pair<String, String>> {
        val s = freeformSetting(c)
        return listOf(
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Perangkat" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "Fitur freeform sistem" to if (freeformFeature(c)) "Ada" else "Tidak terdeteksi",
            "Opsi jendela bentuk bebas" to when (s) { 1 -> "Aktif"; 0 -> "Nonaktif"; else -> "Tidak terbaca" },
            "Picture-in-Picture" to if (c.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) "Ada" else "Tidak terdeteksi",
            "Split-screen" to "Ditentukan sistem; tidak dapat dideteksi aplikasi"
        )
    }
}
