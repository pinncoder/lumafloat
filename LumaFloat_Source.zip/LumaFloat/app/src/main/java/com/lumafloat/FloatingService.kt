package com.lumafloat

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * Layanan foreground yang menampilkan bubble overlay (TYPE_APPLICATION_OVERLAY) dan panel
 * peluncur. Hanya memakai API publik; tidak mengubah jendela aplikasi lain.
 */
class FloatingService : Service() {

    companion object {
        const val ACTION_START = "com.lumafloat.START"
        const val ACTION_STOP = "com.lumafloat.STOP"
        const val ACTION_TOGGLE = "com.lumafloat.TOGGLE_BUBBLE"
        private const val CHANNEL = "luma_float"
        private const val NID = 11
        private val WATCH = setOf("theme", "accent", "bubbleSize", "panelAlpha", "panelScale", "anim", "resetTick")

        @Volatile
        var running = false

        fun start(c: Context) {
            c.startForegroundService(Intent(c, FloatingService::class.java).setAction(ACTION_START))
        }

        fun stop(c: Context) {
            Prefs(c).serviceWanted = false
            c.stopService(Intent(c, FloatingService::class.java))
        }
    }

    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var pal: Palette

    private var bubble: FrameLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: PanelView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var tabHolder: FrameLayout? = null
    private var contentHolder: FrameLayout? = null
    private var bubbleHidden = false
    private var closing = false
    private var panelFocusable = false
    private var tabIndex = 0

    // kalkulator
    private val calcExpr = StringBuilder()
    private var calcDisp: TextView? = null
    private var calcPrev: TextView? = null

    // timer
    private var timerTotal = 5 * 60_000L
    private var timerLeft = timerTotal
    private var timerRunner: CountDownTimer? = null
    private var timerTv: TextView? = null
    private var timerBtn: TextView? = null

    private val fadeRunnable = Runnable {
        bubble?.animate()?.alpha(0.55f)?.setDuration(300)?.start()
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key in WATCH) main.post { applyAppearance() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        pal = Pal.of(prefs)
        val ch = NotificationChannel(CHANNEL, "Layanan floating", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        prefs.raw.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.serviceWanted = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!enterForeground()) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            toast("Izin 'Tampilkan di atas aplikasi lain' belum aktif")
            prefs.serviceWanted = false
            stopSelf()
            return START_NOT_STICKY
        }
        prefs.serviceWanted = true
        if (intent?.action == ACTION_TOGGLE) toggleBubble() else showBubble()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val s = screen()
        bubbleLp?.let { lp ->
            lp.x = lp.x.coerceIn(0, maxOf(0, s.x - lp.width))
            lp.y = lp.y.coerceIn(0, maxOf(0, s.y - lp.height))
            bubble?.let { safeUpdate(it, lp) }
        }
        panelLp?.let { lp ->
            lp.width = lp.width.coerceAtMost(maxOf(dp(240), s.x - dp(16)))
            lp.height = lp.height.coerceAtMost(maxOf(dp(260), (s.y * 0.9f).toInt()))
            clampPanel(lp)
            panel?.let { safeUpdate(it, lp) }
        }
    }

    override fun onDestroy() {
        running = false
        prefs.raw.unregisterOnSharedPreferenceChangeListener(prefListener)
        main.removeCallbacksAndMessages(null)
        timerRunner?.cancel()
        panel?.animate()?.cancel()
        removePanelNow()
        removeBubbleView()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notifikasi

    private fun enterForeground(): Boolean {
        return try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NID, n)
            }
            true
        } catch (e: Exception) {
            prefs.serviceWanted = false
            stopSelf()
            false
        }
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_TOGGLE), flags
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), flags
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_bolt)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("LUMA FLOAT aktif")
            .setContentText(if (bubbleHidden) "Bubble disembunyikan" else "Ketuk bubble untuk membuka panel")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(icon, if (bubbleHidden) "Tampilkan" else "Sembunyikan", toggle).build())
            .addAction(Notification.Action.Builder(icon, "Hentikan", stop).build())
            .build()
    }

    private fun refreshNotification() {
        try {
            getSystemService(NotificationManager::class.java).notify(NID, buildNotification())
        } catch (e: Exception) {
            // abaikan
        }
    }

    // ---------------------------------------------------------------- util

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.currentWindowMetrics.bounds
                return Point(b.width(), b.height())
            }
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            return Point(dm.widthPixels, dm.heightPixels)
        } catch (e: Exception) {
            val dm = resources.displayMetrics
            return Point(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { /* view sudah dilepas */ }
    }

    private fun safeRemove(v: View) {
        try { wm.removeViewImmediate(v) } catch (e: Exception) { /* sudah dilepas */ }
    }

    // ---------------------------------------------------------------- bubble

    private fun applyAppearance() {
        pal = Pal.of(prefs)
        removePanelNow()
        val had = bubble != null
        removeBubbleView()
        if (had && !bubbleHidden) showBubble()
    }

    private fun toggleBubble() {
        bubbleHidden = !bubbleHidden
        if (bubbleHidden) {
            removePanelNow()
            removeBubbleView()
        } else {
            showBubble()
        }
        refreshNotification()
    }

    private fun removeBubbleView() {
        main.removeCallbacks(fadeRunnable)
        bubble?.let {
            it.animate().cancel()
            safeRemove(it)
        }
        bubble = null
        bubbleLp = null
    }

    private fun showBubble() {
        if (bubble != null || bubbleHidden) return
        val size = dp(prefs.bubbleSize)
        val v = FrameLayout(this)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.accent, pal.accent2))
        bg.shape = GradientDrawable.OVAL
        bg.setStroke(dp(2), 0x55FFFFFF)
        v.background = bg
        v.contentDescription = "Bubble LUMA FLOAT"
        val isz = (size * 0.5f).toInt()
        val ic = Ui.icon(this, R.drawable.ic_bolt, pal.onAccent, 1)
        v.addView(ic, FrameLayout.LayoutParams(isz, isz, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val s = screen()
        lp.x = (if (prefs.bubbleX < 0) s.x - size else prefs.bubbleX).coerceIn(0, maxOf(0, s.x - size))
        lp.y = (if (prefs.bubbleY < 0) s.y / 3 else prefs.bubbleY).coerceIn(0, maxOf(0, s.y - size))

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    main.removeCallbacks(fadeRunnable)
                    v.animate().cancel()
                    v.alpha = 1f
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        val sc = screen()
                        lp.x = (ox + dx).toInt().coerceIn(0, maxOf(0, sc.x - lp.width))
                        lp.y = (oy + dy).toInt().coerceIn(0, maxOf(0, sc.y - lp.height))
                        safeUpdate(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel() else snapToEdge()
                    main.postDelayed(fadeRunnable, 2500)
                }
                MotionEvent.ACTION_CANCEL -> main.postDelayed(fadeRunnable, 2500)
            }
            true
        }

        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            toast("Gagal menampilkan bubble. Periksa izin overlay.")
            return
        }
        bubble = v
        bubbleLp = lp
        main.postDelayed(fadeRunnable, 2500)
    }

    private fun savePosition() {
        bubbleLp?.let { prefs.bubbleX = it.x; prefs.bubbleY = it.y }
    }

    private fun snapToEdge() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        val w = screen().x
        val target = if (lp.x + lp.width / 2 < w / 2) 0 else w - lp.width
        val f = prefs.animFactor
        if (f <= 0f) {
            lp.x = target
            safeUpdate(v, lp)
            savePosition()
            return
        }
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = (220 * f).toLong()
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            lp.x = it.animatedValue as Int
            safeUpdate(v, lp)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { savePosition() }
        })
        a.start()
    }

    // ---------------------------------------------------------------- panel

    private inner class PanelView(c: Context) : LinearLayout(c) {
        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                closePanel()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun clampPanel(lp: WindowManager.LayoutParams) {
        val s = screen()
        val top = dp(28)
        lp.x = lp.x.coerceIn(0, maxOf(0, s.x - lp.width))
        lp.y = lp.y.coerceIn(top, maxOf(top, s.y - lp.height - dp(8)))
    }

    private fun openPanel() {
        if (panel != null) return
        closing = false
        val s = screen()
        val margin = dp(8)
        val baseW = when (prefs.panelScale) { 0 -> 300; 2 -> 380; else -> 340 }
        val baseH = when (prefs.panelScale) { 0 -> 400; 2 -> 560; else -> 480 }
        var w = dp(if (prefs.panelW > 0) prefs.panelW else baseW)
        var h = dp(if (prefs.panelH > 0) prefs.panelH else baseH)
        w = w.coerceAtMost(s.x - 2 * margin).coerceAtLeast(dp(240))
        h = h.coerceAtMost((s.y * 0.8f).toInt()).coerceAtLeast(dp(260))

        val root = PanelView(this)
        buildPanel(root)

        val lp = WindowManager.LayoutParams(
            w, h, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN

        val b = bubbleLp
        if (b != null) {
            val bs = b.width
            lp.x = if (w + bs + 2 * margin <= s.x) {
                if (b.x + bs / 2 < s.x / 2) b.x + bs + margin else b.x - w - margin
            } else (s.x - w) / 2
            lp.y = b.y
        } else {
            lp.x = (s.x - w) / 2
            lp.y = (s.y - h) / 2
        }
        clampPanel(lp)

        val f = prefs.animFactor
        if (f > 0f) { root.alpha = 0f; root.scaleX = 0.94f; root.scaleY = 0.94f }
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            toast("Gagal membuka panel")
            return
        }
        panel = root
        panelLp = lp
        panelFocusable = false
        if (f > 0f) {
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration((180 * f).toLong()).start()
        }
    }

    private fun closePanel() {
        val p = panel ?: return
        if (closing) return
        closing = true
        hideKeyboard()
        setPanelFocusable(false)
        val f = prefs.animFactor
        if (f <= 0f) {
            removePanelNow()
        } else {
            p.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration((140 * f).toLong())
                .withEndAction { removePanelNow() }.start()
        }
    }

    private fun removePanelNow() {
        panel?.let {
            it.animate().cancel()
            safeRemove(it)
        }
        panel = null
        panelLp = null
        tabHolder = null
        contentHolder = null
        calcDisp = null
        calcPrev = null
        timerTv = null
        timerBtn = null
        panelFocusable = false
        closing = false
    }

    private fun setPanelFocusable(on: Boolean) {
        val lp = panelLp ?: return
        val p = panel ?: return
        if (on == panelFocusable) return
        panelFocusable = on
        lp.flags = if (on) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        safeUpdate(p, lp)
    }

    private fun hideKeyboard() {
        val p = panel ?: return
        try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(p.windowToken, 0)
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun iconBtn(res: Int, desc: String, onClick: () -> Unit): View {
        val f = FrameLayout(this)
        f.background = Ui.ripple(Ui.round(pal.surface2, dpf(18f)), dpf(18f))
        f.contentDescription = desc
        f.addView(Ui.icon(this, res, pal.text, 18), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(dp(36), dp(36))
        lp.leftMargin = dp(6)
        f.layoutParams = lp
        return f
    }

    private fun buildPanel(root: PanelView) {
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.round(
            Ui.alpha(pal.surface, prefs.panelAlpha * 255 / 100), dpf(22f), pal.stroke, dp(1)
        )
        root.setPadding(dp(12), dp(10), dp(12), dp(10))

        // header (area geser)
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(Ui.icon(this, R.drawable.ic_bolt, pal.accent2, 18))
        val title = Ui.text(this, "  LUMA FLOAT", 15f, pal.text, true)
        header.add(title, w = 0, wt = 1f)
        header.addView(iconBtn(R.drawable.ic_minus, "Tutup panel") { closePanel() })
        header.addView(iconBtn(R.drawable.ic_power, "Hentikan layanan") {
            prefs.serviceWanted = false
            toast("Layanan dihentikan")
            stopSelf()
        })
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = panelLp ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (ox + e.rawX - sx).toInt()
                        lp.y = (oy + e.rawY - sy).toInt()
                        clampPanel(lp)
                        panel?.let { safeUpdate(it, lp) }
                    }
                }
                return true
            }
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val th = FrameLayout(this)
        tabHolder = th
        th.addView(buildTabs())
        root.add(th, t = 8)

        val ch = FrameLayout(this)
        contentHolder = ch
        ch.addView(buildTab(tabIndex), FrameLayout.LayoutParams(-1, -1))
        root.add(ch, h = 0, wt = 1f, t = 8)

        // footer
        val footer = LinearLayout(this)
        footer.orientation = LinearLayout.HORIZONTAL
        footer.gravity = Gravity.CENTER_VERTICAL
        footer.add(Ui.button(this, "Dashboard", pal.surface2, pal.text) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (e: Exception) {
                toast("Gagal membuka dashboard")
            }
            closePanel()
        }, w = 0, wt = 1f)
        footer.add(Ui.button(this, "Sembunyikan bubble", pal.surface2, pal.text) {
            toast("Tampilkan lagi lewat notifikasi")
            toggleBubble()
        }, w = 0, wt = 1.3f, l = 6)

        val handle = object : View(this) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = pal.dim
                strokeWidth = this@FloatingService.dpf(2f)
                strokeCap = Paint.Cap.ROUND
            }

            override fun onDraw(c: Canvas) {
                val w = width.toFloat()
                val h = height.toFloat()
                c.drawLine(w * 0.85f, h * 0.35f, w * 0.35f, h * 0.85f, p)
                c.drawLine(w * 0.85f, h * 0.65f, w * 0.65f, h * 0.85f, p)
            }
        }
        handle.contentDescription = "Ubah ukuran panel"
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ow = 0
            var oh = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = panelLp ?: return false
                val s = screen()
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ow = lp.width; oh = lp.height }
                    MotionEvent.ACTION_MOVE -> {
                        val maxW = maxOf(dp(240), s.x - lp.x - dp(4))
                        val maxH = maxOf(dp(260), s.y - lp.y - dp(8))
                        lp.width = (ow + e.rawX - sx).toInt().coerceIn(dp(240), maxW)
                        lp.height = (oh + e.rawY - sy).toInt().coerceIn(dp(260), maxH)
                        panel?.let { safeUpdate(it, lp) }
                    }
                    MotionEvent.ACTION_UP -> {
                        val d = resources.displayMetrics.density
                        prefs.panelW = (lp.width / d).toInt()
                        prefs.panelH = (lp.height / d).toInt()
                    }
                }
                return true
            }
        })
        footer.addView(handle, LinearLayout.LayoutParams(dp(32), dp(32)))
        root.add(footer, t = 8)
    }

    private fun buildTabs(): LinearLayout {
        val names = listOf("Apps", "Hitung", "Timer", "Catatan")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        names.forEachIndexed { i, n ->
            val sel = i == tabIndex
            val r = dpf(12f)
            val t = Ui.text(this, n, 12f, if (sel) pal.onAccent else pal.dim, sel)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), dp(8), dp(4), dp(8))
            t.background = if (sel) Ui.grad(pal.accent, pal.accent2, r) else Ui.round(pal.surface2, r)
            t.setOnClickListener { selectTab(i) }
            row.add(t, w = 0, wt = 1f, l = if (i == 0) 0 else 4)
        }
        return row
    }

    private fun selectTab(i: Int) {
        tabIndex = i
        hideKeyboard()
        setPanelFocusable(false)
        tabHolder?.let { it.removeAllViews(); it.addView(buildTabs()) }
        contentHolder?.let { it.removeAllViews(); it.addView(buildTab(i), FrameLayout.LayoutParams(-1, -1)) }
    }

    private fun buildTab(i: Int): View = when (i) {
        0 -> appsTab()
        1 -> calcTab()
        2 -> timerTab()
        else -> notesTab()
    }

    // ---------------------------------------------------------------- tab Apps

    private fun launchFromPanel(pkg: String) {
        if (Launcher.launch(this, pkg, prefs)) closePanel()
    }

    private fun quickTile(pkg: String, name: String): View {
        val inst = AppRepo.isInstalled(this, pkg)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(8), dp(12), dp(8), dp(10))
        box.background = Ui.ripple(Ui.round(pal.surface2, dpf(16f)), dpf(16f))
        val iv = android.widget.ImageView(this)
        val d = AppRepo.icon(this, pkg)
        if (d != null) iv.setImageDrawable(d)
        else iv.setImageDrawable(getDrawable(R.drawable.ic_apps)?.mutate()?.also { it.setTint(pal.dim) })
        iv.alpha = if (inst) 1f else 0.5f
        box.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
        val t = Ui.text(this, name, 13f, pal.text, true)
        t.gravity = Gravity.CENTER
        box.add(t, t = 6)
        val s = Ui.text(this, if (inst) "Buka" else "Belum terpasang", 11f, pal.dim)
        s.gravity = Gravity.CENTER
        box.add(s)
        box.setOnClickListener {
            if (inst) launchFromPanel(pkg) else Launcher.notInstalled(this, pkg)
        }
        return box
    }

    private fun appRow(pkg: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(6), dp(4), dp(6))
        row.background = Ui.ripple(Ui.round(pal.surface2, dpf(14f)), dpf(14f))
        val iv = android.widget.ImageView(this)
        iv.setImageDrawable(AppRepo.icon(this, pkg))
        row.addView(iv, LinearLayout.LayoutParams(dp(30), dp(30)))
        val label = Ui.text(this, AppRepo.label(this, pkg), 13f, pal.text)
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        row.add(label, w = 0, wt = 1f, l = 10)
        val star = Ui.text(this, if (prefs.isFavorite(pkg)) "\u2605" else "\u2606", 20f,
            if (prefs.isFavorite(pkg)) pal.accent2 else pal.dim)
        star.setPadding(dp(10), dp(4), dp(10), dp(4))
        star.setOnClickListener {
            prefs.toggleFavorite(pkg)
            selectTab(0)
        }
        row.addView(star)
        row.setOnClickListener { launchFromPanel(pkg) }
        return row
    }

    private fun appsTab(): View {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        sv.addView(col, FrameLayout.LayoutParams(-1, -2))

        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        tiles.add(quickTile(AppRepo.whatsapp(this), "WhatsApp"), w = 0, wt = 1f)
        tiles.add(quickTile(AppRepo.CHROME, "Chrome"), w = 0, wt = 1f, l = 8)
        col.add(tiles)

        val favs = prefs.favorites().filter { AppRepo.isInstalled(this, it) }
        col.add(Ui.text(this, "Favorit", 12f, pal.dim, true), t = 12, b = 4)
        if (favs.isEmpty()) {
            col.add(Ui.text(this, "Belum ada. Tandai \u2606 di halaman Apps pada dashboard.", 12f, pal.dim))
        } else {
            favs.take(8).forEach { col.add(appRow(it), t = 4) }
        }
        val rec = prefs.recents().filter { AppRepo.isInstalled(this, it) }
        col.add(Ui.text(this, "Terakhir dibuka", 12f, pal.dim, true), t = 12, b = 4)
        if (rec.isEmpty()) {
            col.add(Ui.text(this, "Riwayat kosong.", 12f, pal.dim))
        } else {
            rec.take(6).forEach { col.add(appRow(it), t = 4) }
        }
        return sv
    }

    // ---------------------------------------------------------------- tab Kalkulator

    private fun refreshCalc() {
        calcDisp?.text = if (calcExpr.isEmpty()) "0" else calcExpr.toString()
        val hasOp = calcExpr.length > 1 && calcExpr.substring(1).any { it in "+-\u2212\u00D7\u00F7%" }
        val v = if (hasOp) Calc.eval(calcExpr.toString()) else null
        calcPrev?.text = if (v != null) "= " + Calc.format(v) else ""
    }

    private fun calcPress(k: String) {
        val ops = "+\u2212\u00D7\u00F7"
        when {
            k == "C" -> calcExpr.setLength(0)
            k == "DEL" -> if (calcExpr.isNotEmpty()) calcExpr.setLength(calcExpr.length - 1)
            k == "=" -> {
                val v = Calc.eval(calcExpr.toString())
                if (v != null) {
                    calcExpr.setLength(0)
                    calcExpr.append(Calc.format(v))
                } else if (calcExpr.isNotEmpty()) {
                    toast("Ekspresi tidak valid")
                }
            }
            k.length == 1 && k[0] in ops -> {
                if (calcExpr.isEmpty()) {
                    if (k == "\u2212") calcExpr.append(k)
                } else {
                    if (calcExpr.last() in ops) calcExpr.setLength(calcExpr.length - 1)
                    calcExpr.append(k)
                }
            }
            k == "%" -> if (calcExpr.isNotEmpty() && calcExpr.last().isDigit()) calcExpr.append(k)
            else -> calcExpr.append(k)
        }
        refreshCalc()
    }

    private fun calcTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val disp = Ui.text(this, "", 30f, pal.text, true)
        disp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        disp.maxLines = 1
        disp.ellipsize = TextUtils.TruncateAt.START
        disp.setPadding(dp(8), dp(4), dp(8), 0)
        val prev = Ui.text(this, "", 14f, pal.dim)
        prev.gravity = Gravity.END
        prev.maxLines = 1
        prev.setPadding(dp(8), 0, dp(8), dp(6))
        calcDisp = disp
        calcPrev = prev
        refreshCalc()
        col.add(disp)
        col.add(prev)

        val rows = listOf(
            listOf("C", "DEL", "%", "\u00F7"),
            listOf("7", "8", "9", "\u00D7"),
            listOf("4", "5", "6", "\u2212"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "=")
        )
        val opKeys = setOf("\u00F7", "\u00D7", "\u2212", "+", "%")
        for (r in rows) {
            val rl = LinearLayout(this)
            rl.orientation = LinearLayout.HORIZONTAL
            for (k in r) {
                val isOp = k in opKeys
                val isEq = k == "="
                val rad = dpf(14f)
                val btn = Ui.text(this, k, 18f, if (isEq) pal.onAccent else if (isOp) pal.accent2 else pal.text, true)
                btn.gravity = Gravity.CENTER
                btn.background = when {
                    isEq -> Ui.ripple(Ui.grad(pal.accent, pal.accent2, rad), rad)
                    isOp -> Ui.ripple(Ui.round(Ui.alpha(pal.accent, 0x33), rad), rad)
                    else -> Ui.ripple(Ui.round(pal.surface2, rad), rad)
                }
                btn.setOnClickListener { calcPress(k) }
                rl.add(btn, w = 0, h = -1, l = 3, t = 3, r = 3, b = 3, wt = if (k == "0") 2f else 1f)
            }
            col.add(rl, h = 0, wt = 1f)
        }
        return col
    }

    // ---------------------------------------------------------------- tab Timer

    private fun fmtTime(ms: Long): String {
        val s = (ms + 999) / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun refreshTimer() {
        timerTv?.text = fmtTime(timerLeft)
        timerBtn?.text = if (timerRunner != null) "Jeda" else if (timerLeft in 1 until timerTotal) "Lanjut" else "Mulai"
    }

    private fun timerSetTotal(minutes: Int) {
        if (timerRunner != null) return
        timerTotal = minutes.coerceIn(1, 180) * 60_000L
        timerLeft = timerTotal
        refreshTimer()
    }

    private fun timerToggle() {
        val running = timerRunner
        if (running != null) {
            running.cancel()
            timerRunner = null
        } else {
            if (timerLeft <= 0L) timerLeft = timerTotal
            timerRunner = object : CountDownTimer(timerLeft, 250) {
                override fun onTick(ms: Long) { timerLeft = ms; refreshTimer() }
                override fun onFinish() {
                    timerLeft = 0
                    timerRunner = null
                    refreshTimer()
                    vibrate()
                    toast("Timer selesai")
                }
            }.start()
        }
        refreshTimer()
    }

    private fun timerReset() {
        timerRunner?.cancel()
        timerRunner = null
        timerLeft = timerTotal
        refreshTimer()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val eff = VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1)
            if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator.vibrate(eff)
            } else {
                (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(eff)
            }
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun timerTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val tv = Ui.text(this, "", 46f, pal.text, true)
        tv.gravity = Gravity.CENTER
        timerTv = tv
        col.add(tv, t = 12, b = 12)

        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        listOf(1, 5, 10, 25).forEachIndexed { i, m ->
            presets.add(Ui.button(this, "${m}m", pal.surface2, pal.text) { timerSetTotal(m) },
                w = 0, wt = 1f, l = if (i == 0) 0 else 6)
        }
        col.add(presets)

        val step = LinearLayout(this)
        step.orientation = LinearLayout.HORIZONTAL
        step.add(Ui.button(this, "\u22121 menit", pal.surface2, pal.text) {
            timerSetTotal((timerTotal / 60_000L).toInt() - 1)
        }, w = 0, wt = 1f)
        step.add(Ui.button(this, "+1 menit", pal.surface2, pal.text) {
            timerSetTotal((timerTotal / 60_000L).toInt() + 1)
        }, w = 0, wt = 1f, l = 6)
        col.add(step, t = 8)

        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        val go = Ui.gradButton(this, pal, "Mulai") { timerToggle() }
        timerBtn = go
        ctl.add(go, w = 0, wt = 1.4f)
        ctl.add(Ui.button(this, "Reset", pal.surface2, pal.text) { timerReset() }, w = 0, wt = 1f, l = 6)
        col.add(ctl, t = 14)
        refreshTimer()
        return col
    }

    // ---------------------------------------------------------------- tab Catatan

    private fun notesTab(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val et = EditText(this)
        et.hint = "Catatan cepat (tersimpan lokal)"
        et.setHintTextColor(pal.dim)
        et.setTextColor(pal.text)
        et.textSize = 14f
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.background = Ui.round(pal.surface2, dpf(14f))
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.setText(prefs.notes)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { prefs.notes = s?.toString() ?: "" }
        })
        et.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && !panelFocusable) {
                setPanelFocusable(true)
                main.postDelayed({
                    et.requestFocus()
                    try {
                        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                    } catch (ex: Exception) {
                        // abaikan
                    }
                }, 150)
            }
            false
        }
        col.add(et, h = 0, wt = 1f)
        col.add(Ui.button(this, "Selesai mengetik", pal.surface2, pal.text) {
            hideKeyboard()
            et.clearFocus()
            setPanelFocusable(false)
        }, t = 8)
        return col
    }
}
