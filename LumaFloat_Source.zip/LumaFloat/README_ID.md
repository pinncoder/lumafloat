# LUMA FLOAT — Floating Launcher untuk Android

Aplikasi native Android (Kotlin, tanpa dependency pihak ketiga) yang menampilkan **bubble mengambang** dan **panel peluncur** untuk membuka WhatsApp, Chrome, dan aplikasi lain, plus kalkulator, timer, dan catatan cepat.

- Package: `com.lumafloat` · minSdk 26 (Android 8.0) · targetSdk/compileSdk 34
- Target pengguna: Infinix Hot 60i (XOS 15.1.2 / Android 15)
- Tanpa iklan, tanpa analytics, tanpa izin internet, tanpa root, tanpa Accessibility Service, tanpa API tersembunyi.

> **Status jujur:** source code ini ditulis dan diperiksa secara statis (kurung seimbang, XML valid, referensi resource ada), tetapi **belum pernah di-compile dan belum diuji di perangkat apa pun**, termasuk Infinix Hot 60i. Lingkungan tempat kode ini dibuat tidak memiliki Android SDK maupun Gradle. Kemungkinan ada kesalahan kompilasi kecil; lihat bagian "Error build umum".

---

## 1. Persyaratan toolchain

| Komponen | Versi |
|---|---|
| JDK | 17 |
| Gradle | 8.7 |
| Android Gradle Plugin | 8.5.2 |
| Kotlin | 1.9.24 |
| Android SDK Platform | 34 (+ Build-Tools 34.x) |

File Gradle wrapper (`gradlew`, `gradle-wrapper.jar`) **tidak disertakan** (file biner tidak bisa dibuat di sini). `gradle/wrapper/gradle-wrapper.properties` tetap ada sebagai rujukan versi Gradle 8.7.

## 2. Cara membuka dan membangun dari HP Android (tanpa laptop)

### Opsi A — IDE Android di HP (mis. AndroidIDE)
1. Pasang aplikasi IDE yang bisa membangun proyek Gradle di HP (contoh: **AndroidIDE**, proyek open source; unduh hanya dari sumber resminya). Belum diuji dengan proyek ini.
2. Ekstrak `LumaFloat_Source.zip` ke penyimpanan HP (mis. `Download/LumaFloat`). Folder berisi `settings.gradle.kts` harus menjadi root.
3. Di IDE: *Open project* → pilih folder `LumaFloat`.
4. Biarkan IDE menyiapkan JDK 17, Android SDK 34, dan mengunduh Gradle/plugin (perlu internet pada build pertama).
5. Jalankan *Build → Build APK (Debug)*. Hasil biasanya di `app/build/outputs/apk/debug/app-debug.apk`.

### Opsi B — Build di cloud lewat browser HP (GitHub Actions)
Proyek menyertakan `.github/workflows/build-apk.yml`.
1. Buat repositori GitHub (privat juga boleh) lewat browser HP, lalu unggah seluruh isi folder proyek (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK debug** → **Run workflow**.
3. Setelah selesai, unduh artifact `LumaFloat-debug-apk` (berisi `app-debug.apk`).

Catatan: kode proyek ini diunggah ke layanan pihak ketiga (GitHub) pada opsi B; gunakan repositori privat bila perlu.

## 3. Memasang APK
1. Buka file `.apk` dari aplikasi File/Downloads.
2. Jika diminta, izinkan **Pasang aplikasi dari sumber ini** untuk aplikasi pengelola file yang Anda pakai.
3. Jika Play Protect memberi peringatan karena APK debug tidak dikenal, pilih *Install anyway* hanya jika Anda yang membangunnya sendiri.

## 4. Mengaktifkan izin overlay
1. Buka LUMA FLOAT → ketuk **Mulai Floating** (atau tab *Setelan* → *Buka pengaturan izin overlay*).
2. Cari **LUMA FLOAT** di daftar *Tampilkan di atas aplikasi lain* dan aktifkan.
3. Kembali ke aplikasi. Status izin di Home/Setelan akan berubah menjadi *Aktif*.
4. Jika layar izin tidak terbuka: Setelan HP → Aplikasi → LUMA FLOAT → *Tampil di atas aplikasi lain*.

## 5. Mengaktifkan floating bubble
1. Di Home ketuk **Mulai Floating**; izinkan notifikasi bila diminta (layanan foreground memerlukan notifikasi, tetapi tetap berjalan bila ditolak).
2. Bubble muncul di tepi layar. **Geser** untuk memindahkan (menempel ke tepi saat dilepas). **Ketuk** untuk membuka panel.
3. Panel: tab **Apps** (WhatsApp, Chrome, favorit, terakhir dibuka), **Hitung**, **Timer**, **Catatan**.
   - Header panel bisa digeser; pojok kanan-bawah bisa ditarik untuk mengubah ukuran.
   - Tombol **–** menutup panel, **⏻** menghentikan layanan, **Sembunyikan bubble** menyembunyikan bubble sementara (tampilkan lagi lewat notifikasi).
4. Menghentikan layanan: tombol ⏻ di panel, tombol *Hentikan* di notifikasi, atau *Hentikan Floating* di Home.

## 6. Menggunakan WhatsApp dan Chrome
- Dari bubble: buka panel → tab **Apps** → ketuk kartu WhatsApp atau Chrome.
- Dari dashboard: kartu *Peluncuran cepat* di Home, atau tab *Apps*.
- Jika aplikasi belum terpasang, LUMA FLOAT menampilkan pesan dan membuka halaman Play Store (jika tersedia).
- Jika WhatsApp tidak ada tetapi WhatsApp Business terpasang, tombol WhatsApp memakai WhatsApp Business.
- Catatan tombol Catatan: papan ketik hanya muncul saat Anda mengetuk kolom catatan; ketuk **Selesai mengetik** agar panel tidak menahan fokus keyboard dari aplikasi di belakangnya.

## 7. Batasan kompatibilitas multi-window (PENTING)

- Izin overlay **hanya** memungkinkan LUMA FLOAT menggambar bubble dan panelnya sendiri. **Overlay tidak mengubah WhatsApp atau Chrome menjadi jendela kecil.**
- Mode peluncuran (Setelan → *Mode peluncuran aplikasi*):
  - **Normal**: layar penuh; selalu bekerja.
  - **Berdampingan**: memakai `FLAG_ACTIVITY_LAUNCH_ADJACENT`. Ini hanya petunjuk ke sistem dan efektif bila layar sudah dalam split-screen; bukan jaminan jendela bebas.
  - **Jendela bebas**: mengirim `setLaunchBounds` (API publik). Hanya dihormati jika perangkat mendukung dan mengaktifkan freeform (misalnya opsi *Aktifkan jendela bentuk bebas* di Opsi Pengembang bila tersedia). Pada banyak HP, termasuk kemungkinan XOS, opsi ini diabaikan dan aplikasi dibuka normal.
- LUMA FLOAT tidak dapat mengetahui apakah sistem menghormati mode 2/3. Kartu *Kompatibilitas* di Setelan hanya menampilkan indikasi (fitur sistem `freeform_window_management` dan setelan `enable_freeform_support`).
- Belum diverifikasi apakah XOS 15.1.2 pada Infinix Hot 60i menyediakan cara resmi membuka aplikasi pihak ketiga dalam jendela bebas. Jika tidak, gunakan fallback: peluncur cepat, split-screen bawaan XOS (mis. lewat menu recent apps), atau fitur "floating window"/"Multi-window" bawaan XOS bila ada.
- Anda juga dapat memakai fitur sistem secara manual: buka menu recent apps dan cari opsi split-screen/floating pada kartu aplikasi.

## 8. Error build umum

| Gejala | Penyebab / solusi |
|---|---|
| `SDK location not found` | Buat `local.properties` berisi `sdk.dir=/path/ke/Android/sdk` (IDE HP biasanya membuatnya otomatis). |
| `Failed to find target with hash string 'android-34'` | Pasang Android SDK Platform 34 dari SDK Manager IDE. Alternatif: turunkan `compileSdk`/`targetSdk` di `app/build.gradle.kts` ke versi yang terpasang. |
| `Could not resolve com.android.tools.build:gradle` / gagal unduh | Perlu internet pada build pertama; pastikan repositori `google()` dan `mavenCentral()` dapat diakses. |
| `Unsupported class file major version` / Java salah | Gunakan JDK 17. |
| Versi AGP tidak cocok dengan Gradle | AGP 8.5.2 butuh Gradle ≥ 8.7. Jika IDE punya Gradle lain, sesuaikan versi AGP di `build.gradle.kts` sesuai tabel kompatibilitas AGP. |
| `Unresolved reference` / error Kotlin | Proyek ini belum pernah dikompilasi; perbaiki baris yang dilaporkan atau laporkan pesan error lengkapnya agar dapat diperbaiki. |
| `OutOfMemoryError` / daemon mati | Kecilkan `org.gradle.jvmargs` di `gradle.properties` (mis. `-Xmx1g`) dan tutup aplikasi lain. |
| `Execution failed for task :app:mergeDebugResources` | Periksa XML di `app/src/main/res`; ikon vektor memakai path standar. |

## 9. Menghapus aplikasi
1. Hentikan layanan (*Hentikan Floating*).
2. Setelan HP → Aplikasi → **LUMA FLOAT** → **Copot pemasangan**.
3. Data (favorit, catatan, preferensi) ikut terhapus; semuanya hanya tersimpan lokal.

## 10. Fitur yang ada di kode
Home (status layanan, Start/Stop, peluncuran cepat, status izin & multi-window), Apps (daftar via PackageManager, pencarian, ikon asli, status, favorit, aplikasi belum terpasang), Bubble (geser, snap ke tepi, memudar saat idle), Panel (Apps/Kalkulator/Timer/Catatan, geser, ubah ukuran, tutup, sembunyikan bubble, dashboard), Tampilan (3 tema, 3 aksen, ukuran bubble, opasitas panel, ukuran panel, intensitas animasi, reset posisi), Setelan (izin, layanan, mode peluncuran, autostart saat boot, info kompatibilitas, pintasan ke Opsi Pengembang & info aplikasi, panduan masalah), notifikasi foreground dengan aksi Sembunyikan/Tampilkan & Hentikan, deteksi layanan yang dihentikan sistem.

## 11. Struktur proyek
```
app/src/main/java/com/lumafloat/
  MainActivity.kt      dashboard (Home, Apps, Tampilan, Setelan)
  FloatingService.kt   bubble, panel, kalkulator, timer, catatan
  AppRepo.kt           daftar & info aplikasi (PackageManager)
  Launcher.kt          peluncuran (normal / adjacent / launch bounds)
  Compat.kt            indikasi kompatibilitas sistem
  Prefs.kt             preferensi lokal
  Ui.kt                design system (palet, komponen)
  Calc.kt              evaluator kalkulator
  BootReceiver.kt      autostart opsional
```
